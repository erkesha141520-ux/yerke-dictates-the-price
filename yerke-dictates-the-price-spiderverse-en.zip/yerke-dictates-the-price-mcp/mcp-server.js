#!/usr/bin/env node
// Yerke Dictates the Price — MCP Server (works with Claude Desktop, Cursor, VS Code, etc.)
const { McpServer } = require('@modelcontextprotocol/sdk/server/mcp.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const { z } = require('zod');
const { scrapeCompetitors } = require('./lib/browser');
const { calculateServiceCost, suggestDemandPrice, recordAndAnalyzeImpact } = require('./lib/pricing-engine');

const pkg = require('./package.json');
const server = new McpServer({ name: pkg.name, version: pkg.version });

// 1. Service Cost Calculator
server.tool(
  'service_cost_calculator',
  'Рассчитывает реальную себестоимость продукта или услуги, точку безубыточности и рекомендуемую цену продажи с гарантированной прибылью (Service Cost Calculator).',
  {
    item_name: z.string().describe('Название товара или услуги'),
    material_cost: z.number().describe('Затраты на материалы или закуп товара (в тенге/валюте)'),
    labor_hours: z.number().optional().describe('Затраченное время в часах (для услуг)'),
    hourly_rate: z.number().optional().describe('Желаемая ставка за 1 час работы'),
    overhead_cost: z.number().optional().describe('Накладные расходы: упаковка, доставка, аренда на 1 ед.'),
    platform_fee_percent: z.number().optional().describe('Комиссия маркетплейса или эквайринга в % (например, Kaspi 12%)'),
    tax_percent: z.number().optional().describe('Налог в % (по умолчанию 3% для ИП на упрощенке в РК)'),
    target_margin_percent: z.number().optional().describe('Желаемая чистая маржа в % (по умолчанию 30%)')
  },
  async (params) => {
    try {
      const res = calculateServiceCost({
        itemName: params.item_name,
        materialCost: params.material_cost,
        laborHours: params.labor_hours || 0,
        hourlyRate: params.hourly_rate || 0,
        overheadCost: params.overhead_cost || 0,
        platformFeePercent: params.platform_fee_percent || 0,
        taxPercent: params.tax_percent ?? 3,
        targetMarginPercent: params.target_margin_percent ?? 30
      });
      return { content: [{ type: 'text', text: JSON.stringify(res, null, 2) }] };
    } catch (err) {
      return { content: [{ type: 'text', text: `Ошибка расчета: ${err.message}` }], isError: true };
    }
  }
);

// 2. Competitor Benchmarking
server.tool(
  'competitor_benchmarking',
  'Ищет актуальные цены конкурентов на рынке (OLX.kz) через headless Chrome, отсекает мусорные цены и возвращает минимальную, медианную, среднюю и максимальную цену.',
  {
    query: z.string().describe('Название товара или услуги для поиска (например, "химчистка дивана" или "iPhone 15 128")'),
    city: z.string().optional().describe('Город (например, "Алматы", "Астана", "Семей")')
  },
  async ({ query, city }) => {
    const res = await scrapeCompetitors(query, city || '');
    return { content: [{ type: 'text', text: JSON.stringify(res, null, 2) }] };
  }
);

// 3. Demand-Based Pricing Suggestions
server.tool(
  'demand_based_pricing',
  'Рекомендует оптимальную цену на основе текущего спроса, сезонности, срочности заказа и средней цены конкурентов (Demand-Based Pricing Suggestions).',
  {
    base_price: z.number().describe('Ваша базовая цена (из калькулятора себестоимости или текущая цена)'),
    demand_level: z.enum(['slow', 'normal', 'high', 'peak']).describe('Текущий уровень спроса: slow (тихий сезон), normal (обычный), high (высокий), peak (ажиотаж)'),
    seasonality: z.enum(['off_season', 'neutral', 'in_season']).optional().describe('Сезонность товара/услуги'),
    competitor_avg_price: z.number().optional().describe('Средняя цена конкурентов (если известна)'),
    urgency: z.enum(['standard', 'express_24h']).optional().describe('Срочность выполнения заказа')
  },
  async (params) => {
    const res = suggestDemandPrice({
      basePrice: params.base_price,
      demandLevel: params.demand_level,
      seasonality: params.seasonality || 'neutral',
      competitorAvgPrice: params.competitor_avg_price || null,
      urgency: params.urgency || 'standard'
    });
    return { content: [{ type: 'text', text: JSON.stringify(res, null, 2) }] };
  }
);

// 4. Basic Reporting
server.tool(
  'basic_reporting',
  'Сравнивает показатели до и после изменения цены и формирует наглядный табличный отчет о влиянии цены на чистую прибыль (Basic Reporting).',
  {
    item_name: z.string().describe('Название товара или услуги'),
    unit_cost: z.number().describe('Себестоимость 1 единицы товара/услуги'),
    old_price: z.number().describe('Старая цена продажи'),
    old_monthly_sales: z.number().describe('Количество продаж в месяц по старой цене'),
    new_price: z.number().describe('Новая цена продажи'),
    new_monthly_sales: z.number().describe('Количество продаж в месяц по новой цене (факт или прогноз)')
  },
  async (params) => {
    const res = recordAndAnalyzeImpact({
      itemName: params.item_name,
      unitCost: params.unit_cost,
      oldPrice: params.old_price,
      oldMonthlySales: params.old_monthly_sales,
      newPrice: params.new_price,
      newMonthlySales: params.new_monthly_sales
    });
    return { content: [{ type: 'text', text: res.markdown + '\n\n' + JSON.stringify(res.entry, null, 2) }] };
  }
);

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
