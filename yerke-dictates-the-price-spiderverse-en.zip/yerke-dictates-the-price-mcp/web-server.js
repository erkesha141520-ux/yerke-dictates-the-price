// Yerke Dictates the Price — Standalone Web Server + AI Chat Widget API
const http = require('http');
const fs = require('fs');
const path = require('path');
const { scrapeCompetitors } = require('./lib/browser');
const { calculateServiceCost, suggestDemandPrice, recordAndAnalyzeImpact, loadHistory } = require('./lib/pricing-engine');

const PORT = process.env.PORT || 3000;

function sendJson(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && (req.url === '/' || req.url === '/index.html')) {
    const html = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(html);
  }

  if (req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', async () => {
      try {
        const payload = body ? JSON.parse(body) : {};

        if (req.url === '/api/calculate') {
          const result = calculateServiceCost(payload);
          return sendJson(res, 200, { ok: true, result });
        }

        if (req.url === '/api/benchmark') {
          const result = await scrapeCompetitors(payload.query || '', payload.city || '');
          return sendJson(res, 200, { ok: true, result });
        }

        if (req.url === '/api/demand') {
          const result = suggestDemandPrice(payload);
          return sendJson(res, 200, { ok: true, result });
        }

        if (req.url === '/api/report') {
          const result = recordAndAnalyzeImpact(payload);
          return sendJson(res, 200, { ok: true, result });
        }

        if (req.url === '/api/chat') {
          // Умный локальный маршрутизатор + поддержка Gemini API (если задан GEMINI_API_KEY)
          const msg = (payload.message || '').trim();
          const apiKey = process.env.GEMINI_API_KEY || payload.apiKey;

          if (apiKey) {
            const prompt = `Ты — Yerke Dictates the Price, экспертный ИИ-ассистент по ценообразованию для бизнеса и сферы услуг в Казахстане. Отвечай кратко, структурно, с расчетами в тенге (₸). Запрос пользователя: ${msg}`;
            const geminiRes = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
            });
            const geminiData = await geminiRes.json();
            const reply = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text || 'Не удалось получить ответ от Gemini API.';
            return sendJson(res, 200, { ok: true, reply });
          }

          return sendJson(res, 200, {
            ok: true,
            reply: 'Используйте интерактивные кнопки инструментов выше или укажите GEMINI_API_KEY для свободного диалога с нейросетью!'
          });
        }

        return sendJson(res, 404, { ok: false, error: 'Маршрут не найден' });
      } catch (err) {
        return sendJson(res, 400, { ok: false, error: err.message });
      }
    });
    return;
  }

  res.writeHead(404);
  res.end('Not Found');
});

server.listen(PORT, () => {
  console.log(`\n🚀 Yerke Dictates the Price — Spider-Verse AI запущен!`);
  console.log(`👉 Откройте в браузере: http://localhost:${PORT}\n`);
});
