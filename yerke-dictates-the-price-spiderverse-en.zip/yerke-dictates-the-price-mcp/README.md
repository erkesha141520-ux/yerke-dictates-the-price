# 🕷️ YERKE DICTATES THE PRICE (Miles Morales Spider-Verse Edition)

Full-featured AI Pricing Assistant, Web App, and MCP Server styled after **Spider-Man: Miles Morales (Into the Spider-Verse)**.

## What's Inside
1. **Miles Morales UI (Earth-1610 / Earth-42):** Crimson-and-black suit palette, bio-electric neon cyan & yellow sparks (`Venom Strike`), Ben-Day halftone comic dots, tilted comic panels, and speech bubbles.
2. **4 Pricing Superpowers:**
   - `Service Cost Calculator` — Calculates true unit cost, break-even point, Kaspi/tax deductions, and guaranteed net profit.
   - `Demand-Based Pricing` — Dynamic pricing adjustments based on demand, seasonality, and order urgency.
   - `Competitor Benchmarking` — Live competitor scraping on OLX.kz via headless Chrome (`puppeteer-core`) with IQR outlier filtering.
   - `Basic Reporting` — Bottom-line profit growth analysis comparing old vs. new pricing.

## How to Run Locally
```bash
npm install
npm run web
```
Open in browser: **http://localhost:3000**

## GitHub Pages Support
Upload `index.html` directly to the root of your GitHub repository and enable **Settings → Pages → Deploy from a branch (`main` / `/root`)**.
