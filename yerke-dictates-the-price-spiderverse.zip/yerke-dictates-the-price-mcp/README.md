# 🕷️ YERKE DICTATES THE PRICE (Miles Morales Spider-Verse Edition)

Полноценный ИИ-чат и MCP-сервер для ценообразования в комикс-стилистике **Spider-Man: Miles Morales (Into the Spider-Verse)**.

## Что внутри
1. **Дизайн Miles Morales (Earth-1610 / Earth-42):** красно-черный костюм, биоэлектрические неоново-голубые и желтые разряды (`Venom Strike`), комикс-текстуры Ben-Day dots, наклонные карточки и речевые облачка.
2. **4 суперспособности ценообразования:**
   - `Service Cost Calculator` — расчет себестоимости, точки безубыточности и чистой прибыли.
   - `Demand-Based Pricing` — динамическая цена по спросу и сезону.
   - `Competitor Benchmarking` — живой парсинг конкурентов на OLX.kz через фоновый Chrome (`puppeteer-core`).
   - `Basic Reporting` — табличный расчет роста чистой прибыли после изменения цены.

## Как запустить
```bash
npm install
npm run web
```
Откройте в браузере: **http://localhost:3000**
